attribute @s minecraft:generic.scale modifier remove exactly:waschbaer_klein
tag @s remove exactly_klein