attribute @s minecraft:generic.step_height modifier remove exactly:klein_hoch
attribute @s minecraft:generic.step_height modifier add exactly:klein_hoch 0.5 add_value
