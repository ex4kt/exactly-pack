execute store result score #n exactly_clr run kill @e[type=minecraft:item]
tellraw @a ["",{"text":"[Aufräumen] ","color":"gold","bold":true},{"text":"Fertig: ","color":"green"},{"score":{"name":"#n","objective":"exactly_clr"},"color":"white"},{"text":" Item(s) am Boden gelöscht.","color":"green"}]
