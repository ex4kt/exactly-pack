execute if score #t exactly_clr matches 1..5 run function exactly:clr_msg
execute if score #t exactly_clr matches 2..5 run function exactly:clr_sound
execute if score #t exactly_clr matches 1 run function exactly:clr_sound_end
execute if score #t exactly_clr matches 10 run function exactly:clr_msg
execute if score #t exactly_clr matches 15 run function exactly:clr_msg
execute if score #t exactly_clr matches 20 run function exactly:clr_msg
execute if score #t exactly_clr matches 30 run function exactly:clr_msg
execute if score #t exactly_clr matches 45 run function exactly:clr_msg
execute if score #t exactly_clr matches 60 run function exactly:clr_msg
scoreboard players remove #t exactly_clr 1
schedule function exactly:clr_tick 1s
