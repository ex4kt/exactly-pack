# Laeuft 1x pro Sekunde je Spieler (aus tiergroesse): Flug-Insekten-Gestalten bekommen den Tag ex_insekt (Hoehengrenze in tiergroesse_takt)
data remove storage exactly:gestalt id
data modify storage exactly:gestalt id set from entity @s CurrentShape.id
execute if data storage exactly:gestalt {id:"naturalist:butterfly"} run tag @s add ex_insekt
execute if data storage exactly:gestalt {id:"naturalist:dragonfly"} run tag @s add ex_insekt
execute if data storage exactly:gestalt {id:"naturalist:firefly"} run tag @s add ex_insekt
execute if data storage exactly:gestalt {id:"crittersandcompanions:dragonfly"} run tag @s add ex_insekt
execute if data storage exactly:gestalt {id:"crittersandcompanions:ladybug"} run tag @s add ex_insekt
execute if data storage exactly:gestalt {id:"minecraft:bee"} run tag @s add ex_insekt
execute if data storage exactly:gestalt {id:"undergroundworlds:jungle_bee"} run tag @s add ex_insekt
