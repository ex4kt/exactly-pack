attribute @s minecraft:generic.scale modifier add exactly:waschbaer_klein -0.5 add_multiplied_total
tag @s add exactly_klein