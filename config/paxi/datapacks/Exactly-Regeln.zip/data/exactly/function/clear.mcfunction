# /function exactly:clear {zeit:30}  -> zaehlt runter und loescht dann alle Items am Boden (Kurzbefehl /clr 30 ueber Command Aliases)
scoreboard objectives add exactly_clr dummy
schedule clear exactly:clr_tick
$scoreboard players set #t exactly_clr $(zeit)
function exactly:clr_tick
