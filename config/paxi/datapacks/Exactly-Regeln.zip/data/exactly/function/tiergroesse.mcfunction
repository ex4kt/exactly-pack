scoreboard objectives add ex_groesse dummy
# Woodwalkers: als Waschbaer halbe Groesse (Trefferbox 0,4 x 0,45, passt durch Spalten von einem halben Block).
# Woodwalkers nimmt die Masse der Gestalt und rechnet die Spieler-Groesse (generic.scale) mit ein.
# ohne tag-Bedingung: nach Tod/Wiederbeleben kann der Modifikator fehlen, doppeltes Hinzufuegen schlaegt nur still fehl
execute as @a[nbt={CurrentShape:{id:"alexsmobs:raccoon"}}] run function exactly:tiergroesse_klein
execute as @a[tag=exactly_klein,nbt=!{CurrentShape:{id:"alexsmobs:raccoon"}}] run function exactly:tiergroesse_normal
# Kleine Gestalten (Groesse unter 0,8): hoeherer Schritt, damit einzelne Bloecke nicht zur Mauer werden (Wunsch Raphael)
execute as @a store result score @s ex_groesse run attribute @s minecraft:generic.scale get 100
execute as @a[scores={ex_groesse=..79}] run function exactly:klein_hoch
execute as @a[scores={ex_groesse=80..}] run attribute @s minecraft:generic.step_height modifier remove exactly:klein_hoch

# Flug-Insekten (Wunsch Raphael 08.11.): hoechstens 8 Bloecke ueber dem Boden, siehe tiergroesse_takt
tag @a remove ex_insekt
execute as @a run function exactly:insekt_pruefen
