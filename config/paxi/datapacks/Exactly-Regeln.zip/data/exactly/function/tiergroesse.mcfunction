# Woodwalkers: als Waschbaer halbe Groesse (Trefferbox 0,4 x 0,45, passt durch Spalten von einem halben Block).
# Woodwalkers nimmt die Masse der Gestalt und rechnet die Spieler-Groesse (generic.scale) mit ein.
# ohne tag-Bedingung: nach Tod/Wiederbeleben kann der Modifikator fehlen, doppeltes Hinzufuegen schlaegt nur still fehl
execute as @a[nbt={CurrentShape:{id:"alexsmobs:raccoon"}}] run function exactly:tiergroesse_klein
execute as @a[tag=exactly_klein,nbt=!{CurrentShape:{id:"alexsmobs:raccoon"}}] run function exactly:tiergroesse_normal