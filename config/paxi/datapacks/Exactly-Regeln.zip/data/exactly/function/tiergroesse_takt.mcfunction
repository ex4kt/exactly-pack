# Der Gestalt-Check (nbt-Selektor speichert jeden Spieler komplett, samt Rezeptbuch) lief jede Tick = 15 % der Servertick-Zeit (spark).
# Jetzt nur noch einmal pro Sekunde.
scoreboard objectives add ex_takt dummy
# Wunsch Raphael: keine Aegis mehr (spawnen per Mixin in Doerfern, keine Config dafuer); reiner Typ-Selektor, kostet fast nichts
kill @e[type=monsterspellbooks:aegis]
scoreboard players add #t ex_takt 1
execute if score #t ex_takt matches 20.. run function exactly:tiergroesse
execute if score #t ex_takt matches 20.. run scoreboard players set #t ex_takt 0
# Flug-Insekten: mehr als 8 Bloecke Luft darunter -> jede Tick 0,3 Bloecke nach unten (staerker als ihr Steigen, wirkt wie eine Decke)
execute as @a[tag=ex_insekt,gamemode=!creative,gamemode=!spectator] at @s if block ~ ~-1 ~ #minecraft:air if block ~ ~-2 ~ #minecraft:air if block ~ ~-3 ~ #minecraft:air if block ~ ~-4 ~ #minecraft:air if block ~ ~-5 ~ #minecraft:air if block ~ ~-6 ~ #minecraft:air if block ~ ~-7 ~ #minecraft:air if block ~ ~-8 ~ #minecraft:air if block ~ ~-9 ~ #minecraft:air run tp @s ~ ~-0.3 ~
