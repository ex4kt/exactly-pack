# Der Gestalt-Check (nbt-Selektor speichert jeden Spieler komplett, samt Rezeptbuch) lief jede Tick = 15 % der Servertick-Zeit (spark).
# Jetzt nur noch einmal pro Sekunde.
scoreboard objectives add ex_takt dummy
scoreboard players add #t ex_takt 1
execute if score #t ex_takt matches 20.. run function exactly:tiergroesse
execute if score #t ex_takt matches 20.. run scoreboard players set #t ex_takt 0
