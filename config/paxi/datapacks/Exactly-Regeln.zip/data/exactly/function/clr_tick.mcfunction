execute if score #t exactly_clr matches ..0 run function exactly:clr_do
execute if score #t exactly_clr matches 1.. run function exactly:clr_step
