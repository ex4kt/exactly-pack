tellraw @a ["",{"text":"[Aufräumen] ","color":"gold","bold":true},{"text":"Alle Items am Boden werden in ","color":"yellow"},{"score":{"name":"#t","objective":"exactly_clr"},"color":"red","bold":true},{"text":" Sekunde(n) gelöscht!","color":"yellow"}]
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 0.6 1.5
