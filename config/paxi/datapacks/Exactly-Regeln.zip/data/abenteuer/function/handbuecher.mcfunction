give @s patchouli:guide_book[patchouli:book="pneumaticcraft:book"] 1
give @s patchouli:guide_book[patchouli:book="irons_spellbooks:iss_guide_book"] 1
give @s alexsmobs:animal_dictionary 1
give @s securitycraft:sc_manual 1