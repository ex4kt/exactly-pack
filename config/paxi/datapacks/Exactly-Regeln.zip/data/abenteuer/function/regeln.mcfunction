gamerule playersSleepingPercentage 50
gamerule doInsomnia false
gamerule spawnRadius 8
gamerule mobGriefing true
team add alle